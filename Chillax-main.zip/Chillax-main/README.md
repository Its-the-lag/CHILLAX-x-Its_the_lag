# wq presents:   C H I L L A X
![chillaxexample](https://user-images.githubusercontent.com/84565593/200113770-2a31d776-b2ec-469c-bb0a-262b866d4fe0.png)

# Installation
To download the theme in Better Discord Site:
1. Press the download button.
2. Open your Discord and go User Settings > Themes > Open Themes Folder.
3. Drag the theme.css file you just downloaded into the theme folder that opened.
4. Go back to Discord and enable the theme and VOILA you did it.

To download the theme in Github:
1. Go to chillax.theme.css
2. Press the copy raw contents button.
3. Edit the theme.css in your Discord.
4. Select everything and paste in the copied code.


And if you want a YouTube tutorial, go to this link: "https://youtu.be/U0tTENsBS4w"

# What do i do if the theme is outdated?
As where you are right now, you should be at the Better Discord site so just redownload the theme and open your themes folder remove the old one and add the new one you just downloaded.

# Support
For problems installing or using the theme join the support server [https://discord.gg/DrfX6286kF] and ask for help.

# Some of our best of the best
![image](https://user-images.githubusercontent.com/84565593/195045896-bd386edd-3af8-45be-b526-53f55f8ba869.png)
![image](https://user-images.githubusercontent.com/84565593/195045909-cd305dff-669e-4db0-a815-a91c25361f11.png)
![image](https://user-images.githubusercontent.com/84565593/195045924-27e510b4-5de8-4c36-b1ee-11d79487d280.png)
![image](https://user-images.githubusercontent.com/84565593/195045941-21cdf829-9bf7-4c7c-af8f-92b83cd3f256.png)
![image](https://user-images.githubusercontent.com/84565593/195045958-b95c73f3-15fd-4e2a-83c5-9084da71a70e.png)
![image](https://user-images.githubusercontent.com/84565593/195983143-573c15db-0e08-4683-9d70-a891bc34c0c4.png)
![image](https://user-images.githubusercontent.com/84565593/195046542-f1e72971-31ec-47fb-bdeb-9ae139367177.png)
![image](https://user-images.githubusercontent.com/84565593/195046557-2ca6613c-7f09-47b9-9b8c-30358fdac147.png)
![image](https://user-images.githubusercontent.com/84565593/195046937-7043cbe3-70f7-4b8b-979b-6dca2aa20d29.png)
![image](https://user-images.githubusercontent.com/84565593/195045867-6f8374c1-ad21-43e6-8901-d0d09b43b41e.png)
![image](https://user-images.githubusercontent.com/84565593/195983214-b7b9a397-4341-4d15-9316-62c0335c66a2.png)
![image](https://user-images.githubusercontent.com/84565593/195983219-59180643-50ee-44c7-93a2-437b56c4b4c5.png)


# Author
- › Wq
# Helper:
- › Demented Elmo
